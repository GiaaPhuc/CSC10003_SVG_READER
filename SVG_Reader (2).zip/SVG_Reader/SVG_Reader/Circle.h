#ifndef _CIRCLE_H_
#define _CIRCLE_H_

class circle : public ellipse {
private:

public:
	circle();
	~circle();

	void updateProperty();
};

#endif